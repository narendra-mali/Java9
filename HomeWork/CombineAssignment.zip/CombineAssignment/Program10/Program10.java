

class Program10 {

	public static void main(String[] args) {
		
		int num = 10;
		int temp = num;

		for (int i = 1; i < 2; i++){
        		
			temp = temp * temp;
		}

		System.out.println(num + " to the power 2 is " + temp);
      }
}
