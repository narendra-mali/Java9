


class Program7 {

	public static void main(String[] args) {

		int num1 = 50;
		int num2 = 7;
		int num3 = 56;

		if(num1 < num2 && num1 < num3) {

			System.out.println("Minimum number from 50 7 and 56 is = " + num1);
		}

		else if(num2 < num1 && num2 < num3) {

			 System.out.println("Minimum number from 50 7 and 56 is = " + num2);
		}

		else
			 System.out.println("Minimum number from 50 7 and 56 is = " + num3);
	}
}
